const ALLOWED_TYPES = new Set([
  "Obecný dotaz",
  "Žádost",
  "Stížnost",
  "Podnět",
  "Žádost o informace",
  "Jiné"
]);

export async function onRequestPost({ request, env }) {
  let body;
  try {
    body = await request.json();
  } catch {
    return Response.json({ ok: false, error: "Neplatný formulář." }, { status: 400 });
  }

  const { type, name, email, phone, subject, message } = body || {};
  if (!ALLOWED_TYPES.has(type) || !name || !email || !subject || !message) {
    return Response.json({ ok: false, error: "Vyplň všechna povinná pole." }, { status: 400 });
  }

  const fields = [type, name, email, phone || "", subject, message];
  if (fields.some(value => typeof value !== "string" || value.length > 4000)) {
    return Response.json({ ok: false, error: "Některé pole je příliš dlouhé nebo neplatné." }, { status: 400 });
  }

  const webhookUrl = env.DISCORD_WEBHOOK_URL;
  if (!webhookUrl || !webhookUrl.startsWith("https://discord.com/api/webhooks/")) {
    return Response.json({ ok: false, error: "Podatelna není nakonfigurovaná." }, { status: 503 });
  }

  const safe = value => String(value || "Neuvedeno").replace(/@/g, "@\u200b").slice(0, 1800);
  const payload = {
    username: "Webová podatelna – RP prototyp",
    embeds: [{
      title: "Nové podání z webu (RP / DEMO)",
      color: 15158332,
      fields: [
        { name: "Typ podání", value: safe(type), inline: true },
        { name: "Jméno", value: safe(name), inline: true },
        { name: "E-mail", value: safe(email), inline: true },
        { name: "Telefon", value: safe(phone), inline: true },
        { name: "Předmět", value: safe(subject), inline: false },
        { name: "Obsah", value: safe(message), inline: false }
      ],
      footer: { text: "Fiktivní/RP web – nejde o oficiální podatelnu Policie ČR." },
      timestamp: new Date().toISOString()
    }]
  };

  try {
    const response = await fetch(webhookUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    if (!response.ok) {
      return Response.json({ ok: false, error: "Discord podání nepřijal. Zkontroluj webhook a zkus to později." }, { status: 502 });
    }
    return Response.json({ ok: true, message: "Podání bylo předáno do Discordu (RP prototyp)." });
  } catch {
    return Response.json({ ok: false, error: "Služba je dočasně nedostupná." }, { status: 502 });
  }
}
