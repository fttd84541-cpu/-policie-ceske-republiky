# KŘP Praha — Cloudflare Pages + Functions (RP prototyp)

Toto je fiktivní RP web, nikoliv oficiální web Policie ČR.

## Nasazení krok za krokem

1. Rozbal ZIP a nahraj obsah do nového GitHub repozitáře.
2. Vytvoř účet / přihlas se na Cloudflare.
3. Otevři Workers & Pages → Create → Pages → Connect to Git.
4. Vyber svůj GitHub účet a tento repozitář.
5. Nastavení buildu:
   - Framework preset: None
   - Build command: nech prázdné
   - Build output directory: `public`
6. Vytvoř projekt a počkej na deploy.
7. V Cloudflare Pages projektu otevři Settings → Variables and Secrets (někdy Settings → Environment variables).
8. Přidej secret:
   - Name: `DISCORD_WEBHOOK_URL`
   - Value: nový Discord webhook
   - Environment: Production (a případně Preview, pokud chceš testovat náhledy)
9. Ulož změny a spusť nový deploy (Deployments → Retry deployment, nebo udělej malou změnu v GitHubu).
10. Otevři veřejnou `*.pages.dev` adresu a vyzkoušej formulář.

## Důležité
- Endpoint formuláře je `POST /api/podatelna` a implementuje ho `functions/api/podatelna.js`.
- Webhook se do HTML/JS nedává; je pouze v tajné proměnné Cloudflare.
- GitHub Pages samo serverové funkce nespouští, proto se web publikuje přes Cloudflare Pages připojené k GitHubu.
- Pokud byl starý webhook zveřejněn, smaž ho v Discordu a vytvoř nový.
- Neposílej přes tento RP formulář skutečná úřední podání ani citlivé údaje. Přidej ochranu proti spamu, než web veřejně sdílíš.
