const menuButton = document.getElementById("menuButton");
const nav = document.getElementById("mainNav").querySelector(".nav-inner");
menuButton.addEventListener("click", () => {
  const isOpen = nav.classList.toggle("open");
  menuButton.setAttribute("aria-expanded", String(isOpen));
});
nav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
  nav.classList.remove("open");
  menuButton.setAttribute("aria-expanded", "false");
}));

const form = document.getElementById("submissionForm");
const status = document.getElementById("formStatus");
form.addEventListener("submit", async (event) => {
  event.preventDefault();
  status.className = "form-status";
  status.textContent = "Odesílám…";
  const data = Object.fromEntries(new FormData(form).entries());
  try {
    const response = await fetch("/api/podatelna", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data)
    });
    const result = await response.json();
    if (!response.ok || !result.ok) throw new Error(result.error || "Odeslání se nezdařilo.");
    status.className = "form-status success";
    status.textContent = result.message;
    form.reset();
  } catch (error) {
    status.className = "form-status error";
    status.textContent = error.message || "Nepodařilo se odeslat podání. Zkus to později.";
  }
});